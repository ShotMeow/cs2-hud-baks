import radar from './radar.png'

const config = {
    "config": {
        "origin": {
            "x": 557.7279495268139,
            "y": 507.83243734804853
        },
        "pxPerUX": 0.22712933753943218,
        "pxPerUY": -0.23013108811174968
    },
    "file":radar
}

export default config;