import radar from './radar.png'

const config = {
    "config": {
        "origin": {
            "x": 583.2590342775677,
            "y": 428.92222042149115
        },
        "pxPerUX": 0.1983512056034216,
        "pxPerUY": -0.20108163914549304
    },
    "file":radar
}

export default config;